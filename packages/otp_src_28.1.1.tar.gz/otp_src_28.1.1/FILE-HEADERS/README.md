# License Headers

This folder contains a list of all license headers present in the
Erlang/OTP repository. The files here must match exactly what is
in the license header in each file. It is used by license-headers.es
to validate the license headers of all files.

See <../HOWTO/FILE-HEADERS.md> for more details.
