Cross Compiling Erlang/OTP
==========================

See the [$ERL_TOP/HOWTO/INSTALL-CROSS.md][] documentation.

   [$ERL_TOP/HOWTO/INSTALL-CROSS.md]: ../HOWTO/INSTALL-CROSS.md

# %CopyrightBegin%
#
# SPDX-License-Identifier: Apache-2.0
#
# Copyright Ericsson AB 1996-2025. All Rights Reserved.
#
# %CopyrightEnd%
